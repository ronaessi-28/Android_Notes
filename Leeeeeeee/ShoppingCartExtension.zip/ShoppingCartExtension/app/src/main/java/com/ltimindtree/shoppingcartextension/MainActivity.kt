package com.ltimindtree.shoppingcartextension
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompatExtras
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.toString

class MainActivity : AppCompatActivity() {
    lateinit var totalreturn: TextView
    lateinit var totalprice: TextView
    var obj1 = OrderItem("1","PURCHASE",250.0)
    var obj2 = OrderItem("1","PURCHASE",550.0)
    var obj3 = OrderItem("1","PURCHASE",150.0)
    var obj4 = OrderItem("1","RETURN",250.0)
    var obj5 = OrderItem("1","RETURN",150.0)
    val items = listOf(obj1,obj2,obj3,obj4,obj5)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        totalprice = findViewById<TextView>(R.id.totalpurchase_tv)
        totalreturn = findViewById<TextView>(R.id.totalreturn_tv)
        totalreturn.text =items.calculateReturn().toString()
        totalprice.text = items.signedPrice().toString()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}