package com.ltimindtree.shoppingcartextension

data class OrderItem (
    val id : String ,
    val type : String ,
    val price : Double
)

fun OrderItem.isValid(): Boolean{
    if(this.id.isEmpty()){
        return false
    }
    if(this.type!="PURCHASE" && this.type!="RETURN"){
        return false
    }
    if(this.price<0){
        return false
    }
    return true
}

fun List<OrderItem>.signedPrice(): Double{
    for(i in this) {
        if (!i.isValid()) {
            return 0.0
        }
        if (i.type == "purchase") {
            return +i.price
        }
        if (i.type == "RETURN") {
            return -i.price
        }

    }
    return 0.0
}

fun List<OrderItem>.calculateReturn(): Double{
    var total=0.0
    for(item in this){
        if(item.isValid() && item.type== "RETURN"){
            total+=item.price
        }
    }
    return total
}