package com.ltimindtree.washingmachinesealed

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var startBtn: Button
    lateinit var stopBtn: Button
    lateinit var repairBtn: Button
    lateinit var displaytxt: TextView
    val machine = WashingMachineState("LG",8, MachineState.Idle())
    val issue: String = "error"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        startBtn = findViewById<Button>(R.id.start_btn)
        stopBtn = findViewById<Button>(R.id.stop_btn)
        repairBtn = findViewById<Button>(R.id.repair_btn)
        displaytxt = findViewById<TextView>(R.id.display_tv)

        startBtn.setOnClickListener {
            if(machine.startWash()){
                displaytxt.text = machine.getstate()
            }
            else{
                Toast.makeText(this,"Machine is already Wasging", Toast.LENGTH_LONG).show()
            }
        }
        stopBtn.setOnClickListener {
            if(machine.stopWash()){
                displaytxt.text = machine.getstate()
            }
            else{
                Toast.makeText(this,"Machine is already Idle", Toast.LENGTH_LONG).show()
            }

        }
        repairBtn.setOnClickListener {
            if(machine.sendToRepair(issue)){
                displaytxt.text = machine.getstate()
            }
            else{
                Toast.makeText(this,"Machine is already repairing", Toast.LENGTH_LONG).show()
            }

        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

