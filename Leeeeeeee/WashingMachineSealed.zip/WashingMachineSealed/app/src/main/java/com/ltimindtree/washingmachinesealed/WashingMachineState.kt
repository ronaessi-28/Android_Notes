package com.ltimindtree.washingmachinesealed

sealed class MachineState{
    class Idle: MachineState()
    class washing: MachineState()
    class repair(issue: String): MachineState()
}
class WashingMachineState(var brand: String, var capacity: Int, var state: MachineState){

    fun startWash(): Boolean{
        if(state is MachineState.Idle){
            state= MachineState.washing()
            return true
        }
        return false
    }

    fun stopWash(): Boolean{
        if(state is MachineState.washing){
            state= MachineState.Idle()
            return true
        }
        return false
    }

    fun sendToRepair(issue: String): Boolean{
        if(state is MachineState.Idle){
            state = MachineState.repair(issue)
            return true
        }
        return false
    }

    fun getstate(): String{
        if(state is MachineState.Idle){
            return "Machine is Idle"
        }
        else if(state is MachineState.washing){
            return "Machine is washing"
        }
        else{
            return " Machine is on repair"
        }
    }
}